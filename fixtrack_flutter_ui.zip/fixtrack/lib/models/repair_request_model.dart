/// Distinguishes pre-handover workflow stages from the 5 physical repair statuses.
enum WorkflowStage {
  requestPending,     // Step 3-4: Submitted, awaiting business acceptance
  requestRejected,    // Step 4: Business rejected the request
  awaitingEstimate,   // Step 4-5: Business accepted request, preparing estimate
  estimateSent,       // Step 5-6: Estimate sent, awaiting customer decision
  estimateRejected,   // Step 6: Customer rejected the estimate
  bookingConfirmed,   // Step 7-11: Estimate accepted -> Confirmed booking
}

/// The 5 established physical repair progress statuses (Step 9 of workflow).
enum RepairProgressStatus {
  received,
  diagnosing,
  repairing,
  ready,
  collected,
}

extension RepairProgressExtension on RepairProgressStatus {
  String get label {
    switch (this) {
      case RepairProgressStatus.received:
        return 'Received';
      case RepairProgressStatus.diagnosing:
        return 'Diagnosing';
      case RepairProgressStatus.repairing:
        return 'Repairing';
      case RepairProgressStatus.ready:
        return 'Ready';
      case RepairProgressStatus.collected:
        return 'Collected';
    }
  }

  String get description {
    switch (this) {
      case RepairProgressStatus.received:
        return 'The repair business has received your device.';
      case RepairProgressStatus.diagnosing:
        return 'A technician is examining the hardware/software issue.';
      case RepairProgressStatus.repairing:
        return 'Repair work is currently underway.';
      case RepairProgressStatus.ready:
        return 'Your device is repaired and ready for collection.';
      case RepairProgressStatus.collected:
        return 'Device collected. Repair completed.';
    }
  }
}

class RepairRequest {
  final String id;
  final String referenceNumber;
  final String customerName;
  final String customerPhone;
  final String shopId;
  final String shopName;
  final String deviceType;
  final String deviceModel;
  final String problemDescription;
  final DateTime submittedDate;
  WorkflowStage workflowStage;
  double? estimatedCost;
  String? estimatedCompletionTime;
  String? businessNotes;
  RepairProgressStatus? repairStatus;
  DateTime? lastStatusUpdated;

  RepairRequest({
    required this.id,
    required this.referenceNumber,
    required this.customerName,
    required this.customerPhone,
    required this.shopId,
    required this.shopName,
    required this.deviceType,
    required this.deviceModel,
    required this.problemDescription,
    required this.submittedDate,
    this.workflowStage = WorkflowStage.requestPending,
    this.estimatedCost,
    this.estimatedCompletionTime,
    this.businessNotes,
    this.repairStatus,
    this.lastStatusUpdated,
  });
}
