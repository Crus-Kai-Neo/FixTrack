import 'package:flutter/material.dart';
import '../models/repair_request_model.dart';
import '../theme/app_colors.dart';

class RepairStepper extends StatelessWidget {
  final RepairProgressStatus currentStatus;

  const RepairStepper({super.key, required this.currentStatus});

  @override
  Widget build(BuildContext context) {
    const steps = RepairProgressStatus.values;
    final currentIndex = steps.indexOf(currentStatus);

    return Column(
      children: List.generate(steps.length, (index) {
        final step = steps[index];
        final isCompleted = index <= currentIndex;
        final isCurrent = index == currentIndex;
        final isLast = index == steps.length - 1;

        return IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: isCompleted
                          ? (isCurrent
                              ? AppColors.accentTeal
                              : AppColors.primaryNavy)
                          : AppColors.surface,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isCompleted
                            ? (isCurrent
                                ? AppColors.accentTeal
                                : AppColors.primaryNavy)
                            : AppColors.border,
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      isCompleted ? Icons.check : Icons.circle,
                      size: isCompleted ? 16 : 8,
                      color: isCompleted ? Colors.white : AppColors.textMuted,
                    ),
                  ),
                  if (!isLast)
                    Expanded(
                      child: Container(
                        width: 2,
                        color: index < currentIndex
                            ? AppColors.primaryNavy
                            : AppColors.border,
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        step.label,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight:
                              isCurrent ? FontWeight.w700 : FontWeight.w600,
                          color: isCompleted
                              ? AppColors.textPrimary
                              : AppColors.textMuted,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        step.description,
                        style: TextStyle(
                          fontSize: 13,
                          color: isCompleted
                              ? AppColors.textSecondary
                              : AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
