import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';

/// Figure 13 – FixTrack Update Customer Status
class UpdateCustomerStatusScreen extends StatefulWidget {
  final RepairRequest? initialRequest;

  const UpdateCustomerStatusScreen({super.key, this.initialRequest});

  @override
  State<UpdateCustomerStatusScreen> createState() =>
      _UpdateCustomerStatusScreenState();
}

class _UpdateCustomerStatusScreenState
    extends State<UpdateCustomerStatusScreen> {
  final _service = MockDataService.instance;
  RepairRequest? _selectedBooking;
  RepairProgressStatus _selectedStatus = RepairProgressStatus.received;

  @override
  void initState() {
    super.initState();
    final confirmed = _confirmedBookings;
    if (widget.initialRequest != null) {
      _selectedBooking = widget.initialRequest;
      _selectedStatus =
          widget.initialRequest!.repairStatus ?? RepairProgressStatus.received;
    } else if (confirmed.isNotEmpty) {
      _selectedBooking = confirmed.first;
      _selectedStatus =
          confirmed.first.repairStatus ?? RepairProgressStatus.received;
    }
  }

  List<RepairRequest> get _confirmedBookings => _service.businessRequests
      .where((r) => r.workflowStage == WorkflowStage.bookingConfirmed)
      .toList();

  void _saveStatus() {
    if (_selectedBooking == null) return;
    _service.updateRepairProgress(_selectedBooking!.id, _selectedStatus);
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Status updated to "${_selectedStatus.label}" for ${_selectedBooking!.referenceNumber}.'),
        backgroundColor: AppColors.successGreen,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bookings = _confirmedBookings;

    return Scaffold(
      appBar: AppBar(title: const Text('Update Customer Status')),
      body: SafeArea(
        child: bookings.isEmpty
            ? const EmptyStateView(
                icon: Icons.sync_alt_outlined,
                title: 'No Confirmed Bookings',
                subtitle:
                    'Once a customer accepts an estimate, their confirmed booking appears here for status updates.',
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Select Confirmed Booking',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<RepairRequest>(
                      value: bookings.contains(_selectedBooking)
                          ? _selectedBooking
                          : bookings.first,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.devices_other_outlined),
                      ),
                      items: bookings
                          .map(
                            (b) => DropdownMenuItem(
                              value: b,
                              child: Text(
                                '${b.referenceNumber} – ${b.deviceModel} (${b.customerName})',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setState(() {
                            _selectedBooking = val;
                            _selectedStatus =
                                val.repairStatus ?? RepairProgressStatus.received;
                          });
                        }
                      },
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'Repair Progress Stage',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Select the current physical repair status visible on the customer tracking screen.',
                      style: TextStyle(
                          fontSize: 13, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 12),

                    ...RepairProgressStatus.values.map(
                      (status) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(
                              color: _selectedStatus == status
                                  ? AppColors.accentTeal
                                  : AppColors.border,
                              width: _selectedStatus == status ? 1.8 : 1,
                            ),
                          ),
                          child: RadioListTile<RepairProgressStatus>(
                            value: status,
                            groupValue: _selectedStatus,
                            activeColor: AppColors.accentTeal,
                            title: Text(
                              status.label,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                            subtitle: Text(
                              status.description,
                              style: const TextStyle(fontSize: 12),
                            ),
                            onChanged: (val) {
                              if (val != null) {
                                setState(() => _selectedStatus = val);
                              }
                            },
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _saveStatus,
                      icon: const Icon(Icons.check_circle_outline),
                      label: const Text('Save & Notify Customer'),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
