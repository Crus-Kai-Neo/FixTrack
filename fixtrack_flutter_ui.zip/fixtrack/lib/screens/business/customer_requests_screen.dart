import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import '../../widgets/status_badge.dart';
import 'customer_request_details_screen.dart';

/// Figure 10 – FixTrack Customer Requests
class CustomerRequestsScreen extends StatefulWidget {
  const CustomerRequestsScreen({super.key});

  @override
  State<CustomerRequestsScreen> createState() => _CustomerRequestsScreenState();
}

class _CustomerRequestsScreenState extends State<CustomerRequestsScreen> {
  final _service = MockDataService.instance;

  @override
  Widget build(BuildContext context) {
    final incomingRequests = _service.businessRequests
        .where((r) =>
            r.workflowStage == WorkflowStage.requestPending ||
            r.workflowStage == WorkflowStage.awaitingEstimate ||
            r.workflowStage == WorkflowStage.estimateSent)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Customer Requests')),
      body: SafeArea(
        child: incomingRequests.isEmpty
            ? const EmptyStateView(
                icon: Icons.inbox_outlined,
                title: 'No Customer Requests',
                subtitle:
                    'New device repair requests submitted by customers will appear here.',
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: incomingRequests.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final req = incomingRequests[index];
                  return Card(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                CustomerRequestDetailsScreen(request: req),
                          ),
                        );
                        setState(() {});
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  req.referenceNumber,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.primaryNavy,
                                  ),
                                ),
                                StatusBadge.fromRequest(req),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '${req.deviceType} – ${req.deviceModel}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Customer: ${req.customerName}',
                              style: const TextStyle(
                                  fontSize: 13,
                                  color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              req.problemDescription,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Review Request',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.accentTeal,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Icon(Icons.arrow_forward,
                                    size: 16, color: AppColors.accentTeal),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
