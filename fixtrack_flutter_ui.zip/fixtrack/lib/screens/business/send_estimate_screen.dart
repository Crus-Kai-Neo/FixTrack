import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../utils/validators.dart';
import '../../widgets/empty_state_view.dart';

/// Figure 12 – FixTrack Send Estimate
class SendEstimateScreen extends StatefulWidget {
  final RepairRequest? preselectedRequest;

  const SendEstimateScreen({super.key, this.preselectedRequest});

  @override
  State<SendEstimateScreen> createState() => _SendEstimateScreenState();
}

class _SendEstimateScreenState extends State<SendEstimateScreen> {
  final _formKey = GlobalKey<FormState>();
  final _service = MockDataService.instance;

  RepairRequest? _selectedRequest;
  final _costController = TextEditingController();
  final _timeController = TextEditingController();
  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final eligible = _eligibleRequests;
    if (widget.preselectedRequest != null) {
      _selectedRequest = widget.preselectedRequest;
    } else if (eligible.isNotEmpty) {
      _selectedRequest = eligible.first;
    }
  }

  List<RepairRequest> get _eligibleRequests => _service.businessRequests
      .where((r) =>
          r.workflowStage == WorkflowStage.awaitingEstimate ||
          r.workflowStage == WorkflowStage.requestPending)
      .toList();

  @override
  void dispose() {
    _costController.dispose();
    _timeController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _submitEstimate() {
    if (!_formKey.currentState!.validate() || _selectedRequest == null) return;

    _service.sendEstimate(
      requestId: _selectedRequest!.id,
      cost: double.parse(_costController.text.trim()),
      completionTime: _timeController.text.trim(),
      notes: _notesController.text.trim(),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Estimate sent to ${_selectedRequest!.customerName} (${_selectedRequest!.referenceNumber}).'),
        backgroundColor: AppColors.successGreen,
      ),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final eligible = _eligibleRequests;

    return Scaffold(
      appBar: AppBar(title: const Text('Send Estimate')),
      body: SafeArea(
        child: eligible.isEmpty && _selectedRequest == null
            ? const EmptyStateView(
                icon: Icons.calculate_outlined,
                title: 'No Requests Awaiting Estimate',
                subtitle:
                    'Accept an incoming customer repair request first to prepare a cost and time estimate.',
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(18),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Provide Repair Estimate',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Enter the estimated repair cost and expected completion time for customer approval.',
                        style: TextStyle(
                            fontSize: 13, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 18),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (eligible.isNotEmpty)
                                DropdownButtonFormField<RepairRequest>(
                                  value: eligible.contains(_selectedRequest)
                                      ? _selectedRequest
                                      : eligible.first,
                                  isExpanded: true,
                                  decoration: const InputDecoration(
                                    labelText: 'Customer Request',
                                    prefixIcon: Icon(Icons.assignment_outlined),
                                  ),
                                  items: eligible
                                      .map(
                                        (r) => DropdownMenuItem(
                                          value: r,
                                          child: Text(
                                            '${r.referenceNumber} – ${r.deviceModel} (${r.customerName})',
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      )
                                      .toList(),
                                  onChanged: (val) =>
                                      setState(() => _selectedRequest = val),
                                ),
                              if (_selectedRequest != null) ...[
                                const SizedBox(height: 12),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppColors.background,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    'Issue: ${_selectedRequest!.problemDescription}',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _costController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Estimated Repair Cost (Rs.)',
                                  hintText: 'e.g., 4500',
                                  prefixIcon: Icon(Icons.payments_outlined),
                                ),
                                validator: AppValidators.positiveAmount,
                              ),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _timeController,
                                decoration: const InputDecoration(
                                  labelText: 'Estimated Completion Time',
                                  hintText:
                                      'e.g., 2 Working Days / Same Day (5 Hours)',
                                  prefixIcon: Icon(Icons.schedule_outlined),
                                ),
                                validator: (v) => AppValidators.requiredField(
                                    v, 'Estimated completion time'),
                              ),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _notesController,
                                maxLines: 3,
                                decoration: const InputDecoration(
                                  labelText: 'Parts / Repair Notes (Optional)',
                                  hintText:
                                      'Specify replacement components or diagnosis notes...',
                                  alignLabelWithHint: true,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),
                      ElevatedButton.icon(
                        onPressed: _submitEstimate,
                        icon: const Icon(Icons.send_outlined),
                        label: const Text('Send Estimate to Customer'),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
