import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Brand Palette
  static const Color primaryNavy = Color(0xFF0F2942);
  static const Color primaryLight = Color(0xFF1E4976);
  static const Color accentTeal = Color(0xFF0D9488);
  static const Color accentTealLight = Color(0xFFCCFBF1);

  // Neutrals
  static const Color background = Color(0xFFF8FAFC);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color border = Color(0xFFE2E8F0);
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF475569);
  static const Color textMuted = Color(0xFF94A3B8);

  // Semantic Status Colors
  static const Color warningAmber = Color(0xFFD97706);
  static const Color warningBg = Color(0xFFFEF3C7);
  static const Color infoBlue = Color(0xFF2563EB);
  static const Color infoBg = Color(0xFFDBEAFE);
  static const Color successGreen = Color(0xFF059669);
  static const Color successBg = Color(0xFFD1FAE5);
  static const Color errorRed = Color(0xFFDC2626);
  static const Color errorBg = Color(0xFFFEE2E2);
}
