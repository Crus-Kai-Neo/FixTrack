import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/status_badge.dart';
import 'send_estimate_screen.dart';
import 'update_customer_status_screen.dart';

/// Figure 11 – FixTrack Customer Request Details
class CustomerRequestDetailsScreen extends StatefulWidget {
  final RepairRequest request;

  const CustomerRequestDetailsScreen({super.key, required this.request});

  @override
  State<CustomerRequestDetailsScreen> createState() =>
      _CustomerRequestDetailsScreenState();
}

class _CustomerRequestDetailsScreenState
    extends State<CustomerRequestDetailsScreen> {
  final _service = MockDataService.instance;

  void _handleDecision({required bool accept}) {
    _service.respondToCustomerRequest(widget.request.id, accept: accept);
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(accept
            ? 'Request accepted. You can now send a repair estimate.'
            : 'Request rejected.'),
        backgroundColor:
            accept ? AppColors.successGreen : AppColors.errorRed,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final req = widget.request;

    return Scaffold(
      appBar: AppBar(title: const Text('Customer Request Details')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            req.referenceNumber,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primaryNavy,
                            ),
                          ),
                          StatusBadge.fromRequest(req),
                        ],
                      ),
                      const Divider(height: 24, color: AppColors.border),
                      _DetailRow(label: 'Customer Name', value: req.customerName),
                      _DetailRow(label: 'Contact Phone', value: req.customerPhone),
                      _DetailRow(label: 'Device Type', value: req.deviceType),
                      _DetailRow(label: 'Device Model', value: req.deviceModel),
                      const SizedBox(height: 8),
                      const Text(
                        'Reported Problem Description',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          req.problemDescription,
                          style: const TextStyle(
                            fontSize: 14,
                            color: AppColors.textPrimary,
                            height: 1.4,
                          ),
                        ),
                      ),
                      if (req.estimatedCost != null) ...[
                        const Divider(height: 24, color: AppColors.border),
                        _DetailRow(
                          label: 'Proposed Cost',
                          value:
                              'Rs. ${req.estimatedCost!.toStringAsFixed(0)}',
                        ),
                        _DetailRow(
                          label: 'Estimated Time',
                          value: req.estimatedCompletionTime ?? '-',
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              if (req.workflowStage == WorkflowStage.requestPending) ...[
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _handleDecision(accept: false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.errorRed,
                          side: const BorderSide(color: AppColors.errorRed),
                        ),
                        child: const Text('Reject Request'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _handleDecision(accept: true),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accentTeal,
                        ),
                        child: const Text('Accept Request'),
                      ),
                    ),
                  ],
                ),
              ] else if (req.workflowStage == WorkflowStage.awaitingEstimate) ...[
                ElevatedButton.icon(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            SendEstimateScreen(preselectedRequest: req),
                      ),
                    );
                    setState(() {});
                  },
                  icon: const Icon(Icons.request_quote_outlined),
                  label: const Text('Prepare & Send Estimate'),
                ),
              ] else if (req.workflowStage == WorkflowStage.bookingConfirmed) ...[
                ElevatedButton.icon(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            UpdateCustomerStatusScreen(initialRequest: req),
                      ),
                    );
                    setState(() {});
                  },
                  icon: const Icon(Icons.sync_alt_outlined),
                  label: const Text('Update Repair Progress Status'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 125,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
