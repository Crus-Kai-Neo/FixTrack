class RepairShop {
  final String id;
  final String name;
  final String address;
  final String specialization;
  final String phone;
  final String openingHours;
  final List<String> supportedDevices;

  const RepairShop({
    required this.id,
    required this.name,
    required this.address,
    required this.specialization,
    required this.phone,
    required this.openingHours,
    required this.supportedDevices,
  });
}
