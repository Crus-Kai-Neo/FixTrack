import 'package:flutter/material.dart';
import '../../models/shop_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import 'report_repair_screen.dart';

/// Figure 4 – FixTrack Find Repair Shops
class FindRepairShopsScreen extends StatefulWidget {
  const FindRepairShopsScreen({super.key});

  @override
  State<FindRepairShopsScreen> createState() => _FindRepairShopsScreenState();
}

class _FindRepairShopsScreenState extends State<FindRepairShopsScreen> {
  String _searchQuery = '';
  String _selectedDeviceFilter = 'All';

  final List<String> _filters = ['All', 'Smartphone', 'Laptop', 'Desktop PC'];

  @override
  Widget build(BuildContext context) {
    final shops = MockDataService.instance.shops.where((shop) {
      final matchesText = shop.name
              .toLowerCase()
              .contains(_searchQuery.toLowerCase()) ||
          shop.address.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          shop.specialization
              .toLowerCase()
              .contains(_searchQuery.toLowerCase());
      final matchesFilter = _selectedDeviceFilter == 'All' ||
          shop.supportedDevices.contains(_selectedDeviceFilter);
      return matchesText && matchesFilter;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Find Repair Shops')),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Column(
                children: [
                  TextField(
                    onChanged: (val) => setState(() => _searchQuery = val),
                    decoration: const InputDecoration(
                      hintText: 'Search by shop name, location, or specialty...',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 36,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _filters.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final filter = _filters[index];
                        final isSelected = _selectedDeviceFilter == filter;
                        return ChoiceChip(
                          label: Text(filter),
                          selected: isSelected,
                          selectedColor: AppColors.primaryNavy,
                          labelStyle: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : AppColors.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                          onSelected: (_) =>
                              setState(() => _selectedDeviceFilter = filter),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.border),
            Expanded(
              child: shops.isEmpty
                  ? const EmptyStateView(
                      icon: Icons.store_mall_directory_outlined,
                      title: 'No Repair Shops Found',
                      subtitle:
                          'Try adjusting your search keywords or device filter.',
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: shops.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final shop = shops[index];
                        return _ShopCard(
                          shop: shop,
                          onSelectShop: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ReportRepairScreen(preselectedShop: shop),
                              ),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShopCard extends StatelessWidget {
  final RepairShop shop;
  final VoidCallback onSelectShop;

  const _ShopCard({required this.shop, required this.onSelectShop});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: AppColors.primaryNavy.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.build_outlined,
                    color: AppColors.primaryNavy,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        shop.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.location_on_outlined,
                              size: 15, color: AppColors.textSecondary),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              shop.address,
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              shop.specialization,
              style: const TextStyle(
                fontSize: 13,
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.access_time,
                    size: 14, color: AppColors.textMuted),
                const SizedBox(width: 4),
                Text(
                  shop.openingHours,
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(width: 14),
                const Icon(Icons.phone_outlined,
                    size: 14, color: AppColors.textMuted),
                const SizedBox(width: 4),
                Text(
                  shop.phone,
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: shop.supportedDevices
                  .map(
                    (d) => Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.background,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Text(
                        d,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 14),
            ElevatedButton(
              onPressed: onSelectShop,
              child: const Text('Select Shop & Report Repair'),
            ),
          ],
        ),
      ),
    );
  }
}
