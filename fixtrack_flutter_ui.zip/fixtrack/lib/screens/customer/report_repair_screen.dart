import 'package:flutter/material.dart';
import '../../models/shop_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../utils/validators.dart';
import 'track_repairs_screen.dart';

/// Figure 5 – FixTrack Report a Repair
class ReportRepairScreen extends StatefulWidget {
  final RepairShop? preselectedShop;

  const ReportRepairScreen({super.key, this.preselectedShop});

  @override
  State<ReportRepairScreen> createState() => _ReportRepairScreenState();
}

class _ReportRepairScreenState extends State<ReportRepairScreen> {
  final _formKey = GlobalKey<FormState>();
  final _service = MockDataService.instance;

  late RepairShop _selectedShop;
  String _selectedDeviceType = 'Smartphone';
  final _modelController = TextEditingController();
  final _problemController = TextEditingController();

  final List<String> _deviceTypes = [
    'Smartphone',
    'Laptop',
    'Desktop PC',
    'Tablet',
    'Smartwatch',
    'Other Electronic Device',
  ];

  @override
  void initState() {
    super.initState();
    _selectedShop = widget.preselectedShop ?? _service.shops.first;
  }

  @override
  void dispose() {
    _modelController.dispose();
    _problemController.dispose();
    super.dispose();
  }

  void _submitRequest() {
    if (!_formKey.currentState!.validate()) return;

    final refNumber = _service.submitRepairRequest(
      shop: _selectedShop,
      deviceType: _selectedDeviceType,
      deviceModel: _modelController.text.trim(),
      problemDescription: _problemController.text.trim(),
    );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: AppColors.successGreen, size: 28),
            SizedBox(width: 10),
            Expanded(child: Text('Repair Request Submitted')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Your repair request has been sent to the selected repair shop. Keep your reference number for tracking:',
              style: TextStyle(fontSize: 14, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.accentTealLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                'Reference No: $refNumber',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primaryNavy,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Done'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const TrackRepairsScreen()),
              );
            },
            child: const Text('Track Request'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Report a Repair')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Submit Device Repair Details',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'The repair shop will review your request and send an estimated cost and completion time.',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 20),

                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        DropdownButtonFormField<RepairShop>(
                          value: _selectedShop,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            labelText: 'Select Repair Business',
                            prefixIcon: Icon(Icons.storefront_outlined),
                          ),
                          items: _service.shops
                              .map(
                                (s) => DropdownMenuItem(
                                  value: s,
                                  child: Text(
                                    '${s.name} (${s.address})',
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              )
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedShop = val);
                            }
                          },
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField<String>(
                          value: _selectedDeviceType,
                          decoration: const InputDecoration(
                            labelText: 'Electronic Device Type',
                            prefixIcon: Icon(Icons.devices_outlined),
                          ),
                          items: _deviceTypes
                              .map(
                                (t) => DropdownMenuItem(
                                  value: t,
                                  child: Text(t),
                                ),
                              )
                              .toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedDeviceType = val);
                            }
                          },
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _modelController,
                          decoration: const InputDecoration(
                            labelText: 'Device Brand & Model',
                            hintText: 'e.g., Dell Inspiron 15, iPhone 13',
                            prefixIcon: Icon(Icons.smartphone_outlined),
                          ),
                          validator: (v) => AppValidators.requiredField(
                              v, 'Device brand and model'),
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _problemController,
                          maxLines: 4,
                          decoration: const InputDecoration(
                            labelText: 'Problem Description',
                            hintText:
                                'Describe the issue clearly (e.g., screen flickering, battery not charging)...',
                            alignLabelWithHint: true,
                          ),
                          validator: (v) => AppValidators.requiredField(
                              v, 'Problem description'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                ElevatedButton.icon(
                  onPressed: _submitRequest,
                  icon: const Icon(Icons.send_outlined),
                  label: const Text('Submit Repair Request'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
