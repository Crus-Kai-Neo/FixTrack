import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import '../../widgets/status_badge.dart';
import 'repair_booked_screen.dart';

/// Figure 6 – FixTrack Repair Estimates
class RepairEstimatesScreen extends StatefulWidget {
  const RepairEstimatesScreen({super.key});

  @override
  State<RepairEstimatesScreen> createState() => _RepairEstimatesScreenState();
}

class _RepairEstimatesScreenState extends State<RepairEstimatesScreen> {
  final _service = MockDataService.instance;

  void _handleEstimateDecision(RepairRequest req, {required bool accept}) {
    _service.respondToEstimate(req.id, accept: accept);
    setState(() {});

    if (accept) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Estimate accepted! Booking confirmed for ${req.referenceNumber}.'),
          backgroundColor: AppColors.successGreen,
        ),
      );
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => RepairBookedScreen(highlightedRequest: req)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Estimate declined for ${req.referenceNumber}.'),
          backgroundColor: AppColors.errorRed,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final estimates = _service.customerRequests
        .where((r) =>
            r.workflowStage == WorkflowStage.estimateSent ||
            r.workflowStage == WorkflowStage.estimateRejected)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Repair Estimates')),
      body: SafeArea(
        child: estimates.isEmpty
            ? const EmptyStateView(
                icon: Icons.request_quote_outlined,
                title: 'No Pending Repair Estimates',
                subtitle:
                    'When a repair shop sends an estimated cost and completion time, it will appear here for your approval.',
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: estimates.length,
                separatorBuilder: (_, __) => const SizedBox(height: 14),
                itemBuilder: (context, index) {
                  final req = estimates[index];
                  final isActionable =
                      req.workflowStage == WorkflowStage.estimateSent;

                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                req.referenceNumber,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primaryNavy,
                                  fontSize: 13,
                                ),
                              ),
                              StatusBadge.fromRequest(req),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            '${req.deviceType} – ${req.deviceModel}',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Shop: ${req.shopName}',
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const Divider(height: 22, color: AppColors.border),
                          Row(
                            children: [
                              Expanded(
                                child: _EstimateMetric(
                                  label: 'Estimated Cost',
                                  value:
                                      'Rs. ${req.estimatedCost?.toStringAsFixed(0) ?? "N/A"}',
                                  icon: Icons.payments_outlined,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _EstimateMetric(
                                  label: 'Completion Time',
                                  value: req.estimatedCompletionTime ?? 'N/A',
                                  icon: Icons.schedule_outlined,
                                ),
                              ),
                            ],
                          ),
                          if (req.businessNotes != null &&
                              req.businessNotes!.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: AppColors.background,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                'Technician Note: ${req.businessNotes}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ],
                          if (isActionable) ...[
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: () => _handleEstimateDecision(
                                        req,
                                        accept: false),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: AppColors.errorRed,
                                      side: const BorderSide(
                                          color: AppColors.errorRed),
                                    ),
                                    child: const Text('Reject Estimate'),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () => _handleEstimateDecision(
                                        req,
                                        accept: true),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppColors.accentTeal,
                                    ),
                                    child: const Text('Accept & Book'),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class _EstimateMetric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _EstimateMetric({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 15, color: AppColors.accentTeal),
              const SizedBox(width: 5),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          Text(
            value,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
