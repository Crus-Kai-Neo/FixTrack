import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import '../../widgets/status_badge.dart';
import 'customer_request_details_screen.dart';
import 'update_customer_status_screen.dart';

/// Figure 9 – FixTrack Repair Lists
class RepairListsScreen extends StatefulWidget {
  const RepairListsScreen({super.key});

  @override
  State<RepairListsScreen> createState() => _RepairListsScreenState();
}

class _RepairListsScreenState extends State<RepairListsScreen> {
  String _selectedTab = 'Active Bookings';

  @override
  Widget build(BuildContext context) {
    final all = MockDataService.instance.businessRequests;
    final filtered = all.where((r) {
      if (_selectedTab == 'Active Bookings') {
        return r.workflowStage == WorkflowStage.bookingConfirmed &&
            r.repairStatus != RepairProgressStatus.collected;
      } else if (_selectedTab == 'Completed') {
        return r.repairStatus == RepairProgressStatus.collected;
      }
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Repair Lists')),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: ['Active Bookings', 'Completed', 'All Records']
                    .map(
                      (tab) => Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(tab),
                          selected: _selectedTab == tab,
                          selectedColor: AppColors.primaryNavy,
                          labelStyle: TextStyle(
                            color: _selectedTab == tab
                                ? Colors.white
                                : AppColors.textPrimary,
                            fontSize: 13,
                          ),
                          onSelected: (_) =>
                              setState(() => _selectedTab = tab),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
            const Divider(height: 1, color: AppColors.border),
            Expanded(
              child: filtered.isEmpty
                  ? const EmptyStateView(
                      icon: Icons.list_alt_outlined,
                      title: 'No Repairs in This List',
                      subtitle:
                          'Confirmed customer bookings and repair records will appear here.',
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final req = filtered[index];
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      req.referenceNumber,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.primaryNavy,
                                      ),
                                    ),
                                    StatusBadge.fromRequest(req),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  '${req.deviceType} – ${req.deviceModel}',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Customer: ${req.customerName} (${req.customerPhone})',
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: AppColors.textSecondary),
                                ),
                                if (req.estimatedCost != null) ...[
                                  const SizedBox(height: 4),
                                  Text(
                                    'Cost: Rs. ${req.estimatedCost!.toStringAsFixed(0)}  •  Est. Time: ${req.estimatedCompletionTime}',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.accentTeal,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    Expanded(
                                      child: OutlinedButton(
                                        onPressed: () => Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                CustomerRequestDetailsScreen(
                                                    request: req),
                                          ),
                                        ),
                                        child: const Text('Details'),
                                      ),
                                    ),
                                    if (req.workflowStage ==
                                        WorkflowStage.bookingConfirmed) ...[
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () => Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  UpdateCustomerStatusScreen(
                                                      initialRequest: req),
                                            ),
                                          ),
                                          child: const Text('Update Status'),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
