import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import '../../widgets/repair_stepper.dart';
import '../../widgets/status_badge.dart';

/// Figure 8 – FixTrack Track Repairs
class TrackRepairsScreen extends StatefulWidget {
  final String? initialRequestId;

  const TrackRepairsScreen({super.key, this.initialRequestId});

  @override
  State<TrackRepairsScreen> createState() => _TrackRepairsScreenState();
}

class _TrackRepairsScreenState extends State<TrackRepairsScreen> {
  final _service = MockDataService.instance;
  String? _selectedId;

  @override
  void initState() {
    super.initState();
    _selectedId = widget.initialRequestId;
  }

  @override
  Widget build(BuildContext context) {
    final requests = _service.customerRequests;

    return Scaffold(
      appBar: AppBar(title: const Text('Track Repairs')),
      body: SafeArea(
        child: requests.isEmpty
            ? const EmptyStateView(
                icon: Icons.track_changes_outlined,
                title: 'No Repairs to Track',
                subtitle:
                    'Submit a repair request first to monitor its progress here.',
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: requests.length,
                separatorBuilder: (_, __) => const SizedBox(height: 14),
                itemBuilder: (context, index) {
                  final req = requests[index];
                  final isConfirmed =
                      req.workflowStage == WorkflowStage.bookingConfirmed;
                  final isExpanded =
                      _selectedId == req.id || (_selectedId == null && index == 0);

                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          InkWell(
                            onTap: () => setState(() => _selectedId = req.id),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        req.referenceNumber,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.accentTeal,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${req.deviceType} – ${req.deviceModel}',
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        req.shopName,
                                        style: const TextStyle(
                                          fontSize: 13,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                StatusBadge.fromRequest(req),
                              ],
                            ),
                          ),
                          if (isExpanded) ...[
                            const Divider(height: 24, color: AppColors.border),
                            Text(
                              'Reported Issue: ${req.problemDescription}',
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            if (req.estimatedCost != null) ...[
                              const SizedBox(height: 8),
                              Text(
                                'Estimated Cost: Rs. ${req.estimatedCost!.toStringAsFixed(0)}  •  Est. Time: ${req.estimatedCompletionTime}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ],
                            const SizedBox(height: 16),
                            if (isConfirmed && req.repairStatus != null) ...[
                              const Text(
                                'Repair Progress Timeline',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primaryNavy,
                                ),
                              ),
                              const SizedBox(height: 12),
                              RepairStepper(currentStatus: req.repairStatus!),
                            ] else ...[
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: AppColors.background,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  _preHandoverMessage(req.workflowStage),
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  String _preHandoverMessage(WorkflowStage stage) {
    switch (stage) {
      case WorkflowStage.requestPending:
        return 'Waiting for the repair business to review and accept your repair request.';
      case WorkflowStage.awaitingEstimate:
        return 'The repair business accepted your request and is preparing a cost & time estimate.';
      case WorkflowStage.estimateSent:
        return 'Estimate received! Open "Repair Estimates" to accept or reject the quote.';
      case WorkflowStage.requestRejected:
        return 'This repair request was declined by the repair business.';
      case WorkflowStage.estimateRejected:
        return 'You rejected the proposed estimate. No booking was created.';
      case WorkflowStage.bookingConfirmed:
        return 'Booking confirmed. Awaiting device handover.';
    }
  }
}
