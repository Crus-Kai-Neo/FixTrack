import 'package:flutter/material.dart';
import '../../models/repair_request_model.dart';
import '../../services/mock_data_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/empty_state_view.dart';
import '../../widgets/status_badge.dart';
import 'track_repairs_screen.dart';

/// Figure 7 – FixTrack Repair Booked
class RepairBookedScreen extends StatelessWidget {
  final RepairRequest? highlightedRequest;

  const RepairBookedScreen({super.key, this.highlightedRequest});

  @override
  Widget build(BuildContext context) {
    final bookedList = MockDataService.instance.customerRequests
        .where((r) => r.workflowStage == WorkflowStage.bookingConfirmed)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Repair Booked')),
      body: SafeArea(
        child: bookedList.isEmpty
            ? const EmptyStateView(
                icon: Icons.event_available_outlined,
                title: 'No Confirmed Bookings Yet',
                subtitle:
                    'Accept a repair estimate to confirm your booking and hand over your device.',
              )
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (highlightedRequest != null) ...[
                    Container(
                      padding: const EdgeInsets.all(18),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: AppColors.successBg,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.successGreen.withOpacity(0.4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.verified_outlined,
                                  color: AppColors.successGreen, size: 26),
                              SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'Booking Confirmed!',
                                  style: TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.successGreen,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Your repair booking (${highlightedRequest!.referenceNumber}) with ${highlightedRequest!.shopName} is confirmed. Please hand over your device at the shop.',
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.textPrimary,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const Text(
                    'Confirmed Repair Bookings',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...bookedList.map(
                    (booking) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    booking.referenceNumber,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.primaryNavy,
                                    ),
                                  ),
                                  StatusBadge.fromRequest(booking),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${booking.deviceType} – ${booking.deviceModel}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Repair Shop: ${booking.shopName}',
                                style: const TextStyle(
                                    fontSize: 13,
                                    color: AppColors.textSecondary),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Agreed Estimate: Rs. ${booking.estimatedCost?.toStringAsFixed(0) ?? "-"}  •  ${booking.estimatedCompletionTime ?? "-"}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.accentTeal,
                                ),
                              ),
                              const SizedBox(height: 14),
                              ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => TrackRepairsScreen(
                                          initialRequestId: booking.id),
                                    ),
                                  );
                                },
                                icon: const Icon(Icons.timeline, size: 18),
                                label: const Text('Track Repair Progress'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
