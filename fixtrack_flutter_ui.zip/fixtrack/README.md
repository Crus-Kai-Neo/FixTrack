# FixTrack – Electronic Device Repair Booking and Tracking Application

## How to Run in Android Studio
1. Extract this ZIP archive to a folder on your computer (e.g., `C:\Projects\fixtrack` or `~/Projects/fixtrack`).
2. Open **Android Studio** and select **Open** (or **File > Open**).
3. Select the extracted `fixtrack` root folder (containing `pubspec.yaml` and `lib/`).
4. If Android platform folders (`android/`) are not yet generated on your machine, open the **Terminal** tab inside Android Studio and run:
   ```bash
   flutter create . --platforms=android
   flutter pub get
   ```
   *(Note: Running `flutter create . --platforms=android` safely generates standard Gradle/Android wrapper files for your local Flutter SDK version without overwriting `lib/` or `pubspec.yaml`.)*
5. Select an Android Emulator from the top toolbar and click **Run** (`Shift + F10`).

## Documented Screens Included (Figures 2–14)
- **Fig. 2:** Login / Registration (`lib/screens/auth/login_register_screen.dart`)
- **Fig. 3:** Customer Dashboard (`lib/screens/customer/customer_dashboard_screen.dart`)
- **Fig. 4:** Find Repair Shops (`lib/screens/customer/find_repair_shops_screen.dart`)
- **Fig. 5:** Report a Repair (`lib/screens/customer/report_repair_screen.dart`)
- **Fig. 6:** Repair Estimates (`lib/screens/customer/repair_estimates_screen.dart`)
- **Fig. 7:** Repair Booked (`lib/screens/customer/repair_booked_screen.dart`)
- **Fig. 8:** Track Repairs (`lib/screens/customer/track_repairs_screen.dart`)
- **Fig. 9:** Repair Lists (`lib/screens/business/repair_lists_screen.dart`)
- **Fig. 10:** Customer Requests (`lib/screens/business/customer_requests_screen.dart`)
- **Fig. 11:** Customer Request Details (`lib/screens/business/customer_request_details_screen.dart`)
- **Fig. 12:** Send Estimate (`lib/screens/business/send_estimate_screen.dart`)
- **Fig. 13:** Update Customer Status (`lib/screens/business/update_customer_status_screen.dart`)
- **Fig. 14:** Business-Sided Dashboard (`lib/screens/business/business_dashboard_screen.dart`)
