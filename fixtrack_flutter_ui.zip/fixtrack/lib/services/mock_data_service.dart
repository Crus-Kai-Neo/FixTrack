import 'package:flutter/foundation.dart';
import '../models/shop_model.dart';
import '../models/repair_request_model.dart';

class MockDataService extends ChangeNotifier {
  MockDataService._internal();
  static final MockDataService instance = MockDataService._internal();

  String currentCustomerName = 'Aarav Shrestha';
  String currentCustomerPhone = '9841234567';
  String currentBusinessShopId = 'shop_1';
  String currentBusinessName = 'TechCare Electronics & Mobile Hub';

  final List<RepairShop> shops = const [
    RepairShop(
      id: 'shop_1',
      name: 'TechCare Electronics & Mobile Hub',
      address: 'New Road, Kathmandu',
      specialization: 'Smartphones, Laptops & Circuit Repair',
      phone: '01-4225890',
      openingHours: '10:00 AM – 7:00 PM',
      supportedDevices: ['Smartphone', 'Laptop', 'Tablet'],
    ),
    RepairShop(
      id: 'shop_2',
      name: 'Patan IT & Laptop Clinic',
      address: 'Pulchowk, Lalitpur',
      specialization: 'MacBook, Windows Laptops & Motherboards',
      phone: '01-5521430',
      openingHours: '9:30 AM – 6:30 PM',
      supportedDevices: ['Laptop', 'Desktop PC'],
    ),
    RepairShop(
      id: 'shop_3',
      name: 'Bhaktapur QuickFix Gadgets',
      address: 'Suryabinayak, Bhaktapur',
      specialization: 'Mobile Screens, Batteries & Charging Ports',
      phone: '01-6614920',
      openingHours: '10:00 AM – 6:30 PM',
      supportedDevices: ['Smartphone', 'Tablet', 'Smartwatch'],
    ),
    RepairShop(
      id: 'shop_4',
      name: 'Putalisadak Computer Solutions',
      address: 'Putalisadak, Kathmandu',
      specialization: 'PC Hardware, SSD Upgrades & Thermal Servicing',
      phone: '01-4430198',
      openingHours: '10:00 AM – 7:00 PM',
      supportedDevices: ['Laptop', 'Desktop PC', 'Monitor'],
    ),
  ];

  final List<RepairRequest> _requests = [
    RepairRequest(
      id: 'req_101',
      referenceNumber: 'FT-2026-1041',
      customerName: 'Aarav Shrestha',
      customerPhone: '9841234567',
      shopId: 'shop_1',
      shopName: 'TechCare Electronics & Mobile Hub',
      deviceType: 'Laptop',
      deviceModel: 'Dell XPS 13 9310',
      problemDescription:
          'Battery drains within 30 minutes and charging port feels loose when plugged in.',
      submittedDate: DateTime.now().subtract(const Duration(days: 2)),
      workflowStage: WorkflowStage.bookingConfirmed,
      estimatedCost: 6500,
      estimatedCompletionTime: '2 Working Days',
      businessNotes: 'Original 52Wh battery replacement and charging port resoldering.',
      repairStatus: RepairProgressStatus.repairing,
      lastStatusUpdated: DateTime.now().subtract(const Duration(hours: 3)),
    ),
    RepairRequest(
      id: 'req_102',
      referenceNumber: 'FT-2026-1042',
      customerName: 'Aarav Shrestha',
      customerPhone: '9841234567',
      shopId: 'shop_2',
      shopName: 'Patan IT & Laptop Clinic',
      deviceType: 'Smartphone',
      deviceModel: 'Samsung Galaxy S22',
      problemDescription:
          'Cracked front display glass after drop; touch responds intermittently near bottom edge.',
      submittedDate: DateTime.now().subtract(const Duration(hours: 18)),
      workflowStage: WorkflowStage.estimateSent,
      estimatedCost: 14500,
      estimatedCompletionTime: '1 Working Day',
      businessNotes: 'Service-pack OLED display assembly replacement.',
    ),
    RepairRequest(
      id: 'req_103',
      referenceNumber: 'FT-2026-1043',
      customerName: 'Sita Gurung',
      customerPhone: '9803456789',
      shopId: 'shop_1',
      shopName: 'TechCare Electronics & Mobile Hub',
      deviceType: 'Smartphone',
      deviceModel: 'iPhone 13',
      problemDescription:
          'Rear camera lens cracked and main camera fails to focus properly.',
      submittedDate: DateTime.now().subtract(const Duration(hours: 4)),
      workflowStage: WorkflowStage.requestPending,
    ),
    RepairRequest(
      id: 'req_104',
      referenceNumber: 'FT-2026-1044',
      customerName: 'Bikash Tamang',
      customerPhone: '9818765432',
      shopId: 'shop_1',
      shopName: 'TechCare Electronics & Mobile Hub',
      deviceType: 'Laptop',
      deviceModel: 'Lenovo IdeaPad Slim 5',
      problemDescription:
          'Laptop overheats during online classes and fan makes a loud rattling sound.',
      submittedDate: DateTime.now().subtract(const Duration(hours: 9)),
      workflowStage: WorkflowStage.awaitingEstimate,
    ),
    RepairRequest(
      id: 'req_105',
      referenceNumber: 'FT-2026-1035',
      customerName: 'Aarav Shrestha',
      customerPhone: '9841234567',
      shopId: 'shop_3',
      shopName: 'Bhaktapur QuickFix Gadgets',
      deviceType: 'Smartphone',
      deviceModel: 'Redmi Note 11',
      problemDescription: 'Phone not charging even with multiple working cables.',
      submittedDate: DateTime.now().subtract(const Duration(days: 10)),
      workflowStage: WorkflowStage.bookingConfirmed,
      estimatedCost: 1800,
      estimatedCompletionTime: 'Same Day (4 Hours)',
      repairStatus: RepairProgressStatus.collected,
      lastStatusUpdated: DateTime.now().subtract(const Duration(days: 9)),
    ),
  ];

  List<RepairRequest> get allRequests => List.unmodifiable(_requests);

  List<RepairRequest> get customerRequests => _requests
      .where((r) => r.customerName == currentCustomerName)
      .toList();

  List<RepairRequest> get businessRequests => _requests
      .where((r) => r.shopId == currentBusinessShopId)
      .toList();

  String submitRepairRequest({
    required RepairShop shop,
    required String deviceType,
    required String deviceModel,
    required String problemDescription,
  }) {
    final refNum = 'FT-2026-${1045 + _requests.length}';
    final newReq = RepairRequest(
      id: 'req_${DateTime.now().millisecondsSinceEpoch}',
      referenceNumber: refNum,
      customerName: currentCustomerName,
      customerPhone: currentCustomerPhone,
      shopId: shop.id,
      shopName: shop.name,
      deviceType: deviceType,
      deviceModel: deviceModel,
      problemDescription: problemDescription,
      submittedDate: DateTime.now(),
      workflowStage: WorkflowStage.requestPending,
    );
    _requests.insert(0, newReq);
    notifyListeners();
    return refNum;
  }

  void respondToCustomerRequest(String requestId, {required bool accept}) {
    final req = _requests.firstWhere((r) => r.id == requestId);
    req.workflowStage =
        accept ? WorkflowStage.awaitingEstimate : WorkflowStage.requestRejected;
    notifyListeners();
  }

  void sendEstimate({
    required String requestId,
    required double cost,
    required String completionTime,
    String? notes,
  }) {
    final req = _requests.firstWhere((r) => r.id == requestId);
    req.estimatedCost = cost;
    req.estimatedCompletionTime = completionTime;
    req.businessNotes = notes;
    req.workflowStage = WorkflowStage.estimateSent;
    notifyListeners();
  }

  void respondToEstimate(String requestId, {required bool accept}) {
    final req = _requests.firstWhere((r) => r.id == requestId);
    if (accept) {
      req.workflowStage = WorkflowStage.bookingConfirmed;
      req.repairStatus = RepairProgressStatus.received;
      req.lastStatusUpdated = DateTime.now();
    } else {
      req.workflowStage = WorkflowStage.estimateRejected;
    }
    notifyListeners();
  }

  void updateRepairProgress(String requestId, RepairProgressStatus newStatus) {
    final req = _requests.firstWhere((r) => r.id == requestId);
    req.repairStatus = newStatus;
    req.lastStatusUpdated = DateTime.now();
    notifyListeners();
  }
}
