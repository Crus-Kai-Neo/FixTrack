import 'package:flutter/material.dart';
import '../models/repair_request_model.dart';
import '../theme/app_colors.dart';

class StatusBadge extends StatelessWidget {
  final String text;
  final Color textColor;
  final Color backgroundColor;

  const StatusBadge({
    super.key,
    required this.text,
    required this.textColor,
    required this.backgroundColor,
  });

  factory StatusBadge.fromRequest(RepairRequest req) {
    if (req.workflowStage == WorkflowStage.bookingConfirmed &&
        req.repairStatus != null) {
      switch (req.repairStatus!) {
        case RepairProgressStatus.received:
          return const StatusBadge(
            text: 'Received',
            textColor: AppColors.infoBlue,
            backgroundColor: AppColors.infoBg,
          );
        case RepairProgressStatus.diagnosing:
          return const StatusBadge(
            text: 'Diagnosing',
            textColor: AppColors.warningAmber,
            backgroundColor: AppColors.warningBg,
          );
        case RepairProgressStatus.repairing:
          return const StatusBadge(
            text: 'Repairing',
            textColor: AppColors.infoBlue,
            backgroundColor: AppColors.infoBg,
          );
        case RepairProgressStatus.ready:
          return const StatusBadge(
            text: 'Ready for Pickup',
            textColor: AppColors.successGreen,
            backgroundColor: AppColors.successBg,
          );
        case RepairProgressStatus.collected:
          return const StatusBadge(
            text: 'Collected',
            textColor: AppColors.textSecondary,
            backgroundColor: AppColors.border,
          );
      }
    }

    switch (req.workflowStage) {
      case WorkflowStage.requestPending:
        return const StatusBadge(
          text: 'Pending Review',
          textColor: AppColors.warningAmber,
          backgroundColor: AppColors.warningBg,
        );
      case WorkflowStage.requestRejected:
        return const StatusBadge(
          text: 'Request Declined',
          textColor: AppColors.errorRed,
          backgroundColor: AppColors.errorBg,
        );
      case WorkflowStage.awaitingEstimate:
        return const StatusBadge(
          text: 'Preparing Estimate',
          textColor: AppColors.infoBlue,
          backgroundColor: AppColors.infoBg,
        );
      case WorkflowStage.estimateSent:
        return const StatusBadge(
          text: 'Estimate Ready',
          textColor: AppColors.accentTeal,
          backgroundColor: AppColors.accentTealLight,
        );
      case WorkflowStage.estimateRejected:
        return const StatusBadge(
          text: 'Estimate Rejected',
          textColor: AppColors.errorRed,
          backgroundColor: AppColors.errorBg,
        );
      case WorkflowStage.bookingConfirmed:
        return const StatusBadge(
          text: 'Booking Confirmed',
          textColor: AppColors.successGreen,
          backgroundColor: AppColors.successBg,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: textColor,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
