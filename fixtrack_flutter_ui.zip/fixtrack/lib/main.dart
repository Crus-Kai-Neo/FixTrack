import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/auth/login_register_screen.dart';

void main() {
  runApp(const FixTrackApp());
}

class FixTrackApp extends StatelessWidget {
  const FixTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FixTrack',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const LoginRegisterScreen(),
    );
  }
}
